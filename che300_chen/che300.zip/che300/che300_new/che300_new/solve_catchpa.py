from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

import time
from bs4 import BeautifulSoup
from PIL import Image
import requests
import cv2


class Yanzhengma():
    def __init__(self):
        self.chrome_opts = Options()
        self.chrome_opts.add_argument('--headless')
        self.driver = webdriver.Chrome(executable_path='/home/machao/下载/chromedriver_linux64/chromedriver', options=self.chrome_opts)
        self.wait = WebDriverWait(self.driver, 15)
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36',
        }
        
        
    def get_pic(self, url):
        self.driver.get(url)
        test_image = self.wait.until(EC.presence_of_element_located((By.ID, 'dx_captcha_basic_bg_1')))
        self.driver.maximize_window()
        self.driver.save_screenshot('che300.png')
        
        soup = BeautifulSoup(self.driver.page_source, 'html5lib')
        
        # 下载保存缺口小图片        
        try:
            img_url = soup.select('div#dx_captcha_basic_sub-slider_1 img')[0].get('src')
            print(img_url)
            with open('slider.webp', 'wb') as f:
                f.write(requests.get(img_url, headers=self.headers).content)
            slider = Image.open('slider.webp')
            slider.load()
            slider.save('slider.png')
        except Exception as e:
            print(repr(e))
            
#         # 在保存的页面截图中 截取验证码图片
        left, top, right, bottom = test_image.location['x'], test_image.location['y'], \
                                    test_image.location['x'] + test_image.size['width'],\
                                    test_image.location['y'] + test_image.size['height']
        pic = Image.open('che300.png')
        yanzheng_img = pic.crop((left, top, right, bottom))
        yanzheng_img.save('验证码.png')
        
    def get_offset(self):
        '''
        使用cv2获取图片缺口偏移量
        '''
        target_rgb = cv2.imread('验证码.png')
        template_rgb = cv2.imread('slider.png', 0)
        target_gray = cv2.cvtColor(target_rgb, cv2.COLOR_BGR2GRAY)
        res = cv2.matchTemplate(target_gray, template_rgb, cv2.TM_CCOEFF_NORMED)
        value = cv2.minMaxLoc(res)
        if abs(value[0]) > abs(value[1]):
            distance = value[2][0]
            print('缺口偏移量：', distance)
        else:
            distance = value[3][0]
            print('缺口偏移量：', distance)
            
        return distance
    
    def get_track(self, distance):
        '''
        根据偏移量获取移动轨迹
        '''
        tracks = []    # 移动轨迹
        # 当前位移
        current = 0
        # 减速阈值
        mid = distance * 4 / 5
        # 计算间隔
        t = 0.2
        # 初速度
        v = 0
        
        while current < distance:
            if current < mid:
                a = 2  # 加速度越大，滑动速度越快
            else:
                a = -3  # 加速度为-3
            v0 = v
            # 0.3s时间内的位移
            s = v0 * t + 0.5 * a * (t ** 2)
            # 当前位置
            current += s
            # 添加到轨迹列表
            tracks.append(round(s))
            # 速度已经达到V，该速度作为下次的初速度
            v = v0 + a * t
            
        return tracks
        
    def move(self, track=None):
        ActionChains(self.driver).click_and_hold(self.driver.find_element_by_id("dx_captcha_basic_slider-img-animated-wrap_1")).perform()
        for x in track:
            ActionChains(self.driver).move_by_offset(xoffset=x, yoffset=0).perform()

#         ActionChains(self.driver).move_by_offset(xoffset=track, yoffset=0).perform()
        time.sleep(0.7)
        ActionChains(self.driver).release().perform()
        
# 车300 url
if __name__ == "__main__":
    url = 'https://www.che300.com/partner/result.php?prov=22&city=22&brand=30&series=386&model=21359&registerDate=2014-1&mileAge=13.17&intention=0&partnerId=douyin&unit=1&sn=93a15125acc736ab66bb791a1e37ae1a&sld=cd'
    che300 = Yanzhengma()
    i = 0
    while i < 10:
        time.sleep(1)
        che300.get_pic(url)
        distance = che300.get_offset()
        track = che300.get_track(distance)
        che300.move(track)
        i += 1
    print('ok')